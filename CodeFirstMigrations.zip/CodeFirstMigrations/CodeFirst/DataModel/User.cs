﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CodeFirst.DataModel
{
    public class User
    {
        [Key]
        public string EmailId { get; set; }
        public 	string  UserRole {get;set;}
        public string UserName {get;set;}

        public virtual List<UserGridView> UserGridViews { get; set; }
    }
}
