﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using Newtonsoft.Json;  

namespace CodeFirst.DataModel
{
    public class UserGridView
    {
        [Key]
        public string EmailId { get; set; }
        //public string GridViewEncoding { get; set; }
        //public JObject User_Preferences {get;set;}
        //public string GridViewName { get; set; }
        // public string[] filters {get;set;}
        // public string[] groups {get;set;}
        public string UserPreference {get;set;}

        [ForeignKey("EmailId")]
        public virtual User Users { get; set; }
    }
}
