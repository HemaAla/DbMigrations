﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CodeFirst.Migrations
{
    public partial class PricingsolutionTablesaddinguserpref : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "GridViewEncoding",
                table: "UserGridViews");

            migrationBuilder.RenameColumn(
                name: "GridViewName",
                table: "UserGridViews",
                newName: "UserPreference");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "UserPreference",
                table: "UserGridViews",
                newName: "GridViewName");

            migrationBuilder.AddColumn<string>(
                name: "GridViewEncoding",
                table: "UserGridViews",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
