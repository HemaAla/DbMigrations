using CodeFirst.DataModel;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;

namespace CodeFirst
{
    public class MyDbContext : DbContext
    {
        // /// <summary>
        // /// Represents the People table
        // /// </summary>
        // public DbSet<Person> People { get; set; }

        // /// <summary>
        // /// Represents the Addresses table
        // /// </summary>
        // public DbSet<Address> Addresses { get; set; }

        /// <summary>
        /// Configures the connection to the Sql Server database instance
        /// </summary>
        /// <param name="optionsBuilder"></param>	

        /// <summary>
        /// Represents the Addresses table
        /// </summary>
       public DbSet<ApiEndpoint> ApiEndpoints { get; set; }

       /// <summary>
        /// Represents the Addresses table
        /// </summary>
      public DbSet<ApiConfiguration> ApiConfigurations { get; set; }

       /// <summary>
        /// Represents the Addresses table
        /// </summary>
      public DbSet<MarketQuote> MarketQuotes { get; set; }

      /// <summary>
        /// Represents the Addresses table
        /// </summary>
      public DbSet<User> Users { get; set; }
      public DbSet<UserGridView> UserGridViews { get; set; }
      public DbSet<Symbol> Symbols { get; set; }
		
	


	// public DbSet<ApiEndpoint> ApiEndpoints { get; set; }
    //     public DbSet<ApiConfiguration> ApiConfigurations { get; set; }
    //     public DbSet<MarketQuote> MarketQuotes { get; set; }
    //     public DbSet<User> Users { get; set; }
    //     public DbSet<UserGridView> UserGridViews { get; set; }
    //     public DbSet<Symbol> Symbols { get; set; }
		
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var configuration = new ConfigurationBuilder()
                   .SetBasePath(AppContext.BaseDirectory)
                   .AddJsonFile("appsettings.json", false)
                   .Build();

            var connectionString = configuration["ConnectionStrings:DefaultConnection"];
            optionsBuilder.UseSqlServer(connectionString);
        }
    }
}
